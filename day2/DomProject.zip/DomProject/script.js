
let div = document.querySelector("div");

let button = document.getElementById("aqua");

button.onclick = function(){
        div.style.backgroundColor = "aqua";
        div.innerHTML = button.innerHTML;
    
}

let but = document.getElementById("teal");

but.onclick = function(){
        div.style.backgroundColor = "teal";
        div.innerHTML = but.innerHTML;
}

let but2 = document.getElementById("pink");

but2.onclick = function(){
        div.style.backgroundColor = "pink";
        div.innerHTML = but2.innerHTML;
}

let but3 = document.getElementById("purple");

but3.onclick = function(){
        div.style.backgroundColor = "purple";
        div.innerHTML = but3.innerHTML;
}
let but4 = document.getElementById("colorless");

but4.onclick = function(){
        div.style.backgroundColor = "white";
        div.innerHTML = but4.innerHTML;
}









